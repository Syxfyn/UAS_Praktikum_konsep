class TourismPlace {
  String title;
  String Author;
  String description;
  String Harga;
  String Stock;
  String imageAsset;
  List<String> imageUrls;

  TourismPlace({
    required this.title,
    required this.Author,
    required this.description,
    required this.Harga,
    required this.Stock,
    required this.imageAsset,
    required this.imageUrls,
  });
}

var tourismPlaceList = [
  TourismPlace(
      title: 'BMW M1000rr',
      Author: 'BMW',
      description:
          'BMW M1000RR adalah motor sport premium 999 cc dengan tenaga 212 hp, aerodinamika winglet, sasis ringan, dan fitur elektronik canggih, dirancang untuk performa balap dan jalan raya.',
      Harga: 'Rp900.000.000',
      Stock: '15',
      imageAsset: 'images/BMW m1000rr.jpg',
      imageUrls: [
        'https://cdn.idntimes.com/content-images/post/20221005/screenshot-2022-10-05-at-10-46-33-wd5dkfbb75hlzp5xgliaon3gnqjpg-gambar-jpeg-image-1440-1080-piksel-skala-59-fcb922b4684f8c70c66e5a4477fc0827_600x400.png',
        'https://imgcdn.oto.com/large/gallery/exterior/67/936/bmw-s-1000-rr-slant-front-view-full-image-798854.jpg?tr=w-510,h-340',
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTgoVN9GyxF_KGZBlWvc-ePyPHSITA3l4N3A&s'
      ]),
  TourismPlace(
    title: 'Yamaha R1M',
    Author: 'Yamaha',
    description:
        'Yamaha R1M adalah motor sport 998 cc berperforma tinggi dengan tenaga 200 hp, sasis ringan berbahan karbon, suspensi semi-aktif Öhlins, dan teknologi canggih seperti IMU 6 sumbu serta kontrol traksi, dirancang untuk lintasan balap dan jalan raya.',
    Harga: 'Rp800.000.000',
    Stock: '48',
    imageAsset: 'images/Yamaha R1m.jpg',
    imageUrls: [
      'https://static.promediateknologi.id/crop/0x0:0x0/0x0/webp/photo/p2/222/2024/09/23/17-1140850299.jpg',
      'https://imgcdn.oto.com/large/gallery/exterior/84/1298/yamaha-r1m-front-tyre-333334.jpg',
      'https://imgcdn.oto.com/large/gallery/exterior/84/1298/yamaha-r1m-head-light-view-122822.jpg',
    ],
  ),
  TourismPlace(
    title: 'Ducati Panigale V4',
    Author: 'Ducati',
    description:
        'Ducati Panigale V4 adalah motor sport 1.103 cc dengan tenaga hingga 215 hp, desain aerodinamis dengan winglet, rangka ringan, dan fitur elektronik canggih seperti kontrol traksi, ABS kornering, dan mode balap, memberikan performa maksimal di lintasan maupun jalan raya.',
    Harga: 'Rp1.200.000.000',
    Stock: '5',
    imageAsset: 'images/Ducati panigalle v4.jpg',
    imageUrls: [
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSd1-h1XQklnFMYpkd14y5MIZiKBHZ6c0a9Zw&s',
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRJotJeeLhZCnhguJc_B2vaVnWOa92Kr5aISQ&s',
      'https://i0.wp.com/cdn.pertamax7.com/wp-content/uploads/2020/11/Spesifikasi-Ducati-Panigale-V4-SP-MY2021.jpg?ssl=1',
    ],
  ),
  TourismPlace(
    title: 'Honda CBR1000rr',
    Author: 'Honda',
    description:
        'Honda CBR1000RR adalah motor sport 999 cc dengan tenaga hingga 189 hp, desain aerodinamis, sasis ringan, dan fitur teknologi seperti kontrol traksi HSTC, ABS, dan mode berkendara, dirancang untuk keseimbangan performa dan kenyamanan di lintasan maupun jalan raya.',
    Harga: 'Rp700.000.000',
    Stock: '24',
    imageAsset: 'images/Honda cbr1000rr.jpg',
    imageUrls: [
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ5dlWKYnEYOA3BCrPOIufGqIZ3DOXCFcTx4Q&s',
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSsw1iye76OmPgUwi6t0064oZkg3CCAj_MJHQ&s',
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQaukp1FbVXJCUqBgvyNnrnR2q4B8lbvUxFuQ&s',
    ],
  ),
  TourismPlace(
    title: 'Kawazaki Ninja H2R',
    Author: 'Kawazaki',
    description:
        'Kawasaki Ninja H2R adalah motor sport hyperbike 998 cc dengan supercharger, menghasilkan tenaga ekstrem hingga 310 hp. Dibuat khusus untuk lintasan, H2R dilengkapi desain aerodinamis dengan winglet, sasis trellis ringan, dan teknologi canggih untuk performa balap maksimal.',
    Harga: 'Rp2.000.000.000',
    Stock: '2',
    imageAsset: 'images/Kawazaki ninja H2r.jpg',
    imageUrls: [
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR3X7OOrFeUPjYteDuh-kFkwWMVA1T3XA6Zvg&s',
      'https://upload.wikimedia.org/wikipedia/commons/thumb/4/4f/Kawasaki_Ninja_H2.jpg/1200px-Kawasaki_Ninja_H2.jpg',
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTtWzhK49BHrzvD0KoyeYSqjhD1O3LY_vP50A&s',
    ],
  ),
];
